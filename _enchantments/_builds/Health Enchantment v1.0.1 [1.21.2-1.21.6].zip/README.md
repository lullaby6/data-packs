# Health Enchantment

[![Discord](https://img.shields.io/discord/1327308441324097681?label=discord&color=blue&logo=discord)](https://discord.gg/5UdcDa5xNC)
[![Modrinth](https://img.shields.io/modrinth/dt/health-enchantment-data-pack?label=modrinth&logo=modrinth)](https://modrinth.com/datapack/health-enchantment)
[![License](https://img.shields.io/github/license/lullaby6/enchantments-data-pack)](https://github.com/lullaby6/enchantments-data-pack/blob/main/LICENSE)

`Health` is a new enchantment for the armor with five levels that increases your max health.

The enchantment can be obtained from the enchantment table, loot chests or trading with villagers.

## ⌨️ Commands

Give:

```mcfunction
/loot give @s loot health_enchantment:<level>
```

Enchant:

```mcfunction
/enchant @s health_enchantment:health <level>
```

## 🪪 License

[AGPL-3.0-or-later](https://github.com/lullaby6/enchantments-data-pack/blob/main/LICENSE)