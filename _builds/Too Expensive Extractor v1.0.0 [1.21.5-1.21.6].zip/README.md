# Too Expensive Extractor

[![Discord](https://img.shields.io/discord/1327308441324097681?label=discord&color=blue&logo=discord)](https://discord.gg/5UdcDa5xNC)
[![Modrinth](https://img.shields.io/modrinth/dt/too-expensive-extractor?label=modrinth&logo=modrinth)](https://modrinth.com/datapack/too-expensive-extractor)
[![License](https://img.shields.io/github/license/lullaby6/data-packs)](https://github.com/lullaby6/data-packs/blob/main/LICENSE)

Extract Too Expensive from armor, tools and weapons!

## 🛠️ Recipe

![Recipe](https://raw.githubusercontent.com/lullaby6/data-packs/refs/heads/main/Too%20Expensive%20Extractor/images/recipe.png)

## ⌨️ Commands

Give:

```mcfunction
/loot give @s loot too_expensive_extractor:too_expensive_extractor
```

## 🪪 License

[AGPL-3.0-or-later](https://github.com/lullaby6/data-packs/blob/main/LICENSE)