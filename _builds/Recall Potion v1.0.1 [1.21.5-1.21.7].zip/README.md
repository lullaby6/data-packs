# Recall Potion

[![Discord](https://img.shields.io/discord/1327308441324097681?label=discord&color=blue&logo=discord)](https://discord.gg/5UdcDa5xNC)
[![Modrinth](https://img.shields.io/modrinth/dt/ly-recall-potion?label=modrinth&logo=modrinth)](https://modrinth.com/datapack/ly-recall-potion)
[![License](https://img.shields.io/github/license/lullaby6/data-packs)](https://github.com/lullaby6/data-packs/blob/main/LICENSE)

## 🛠️ Recipe

![recipe](https://raw.githubusercontent.com/lullaby6/recall-potion-data-pack/refs/heads/main/images/recipe.png)

## ⌨️ Commands

Give:

```mcfunction
/loot give @s loot recall_potion:recall_potion
```

## 🪪 License

[AGPL-3.0-or-later](https://github.com/lullaby6/data-packs/blob/main/LICENSE)