forceload remove ~ ~

kill @s