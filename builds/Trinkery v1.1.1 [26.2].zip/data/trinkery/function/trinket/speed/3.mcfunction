advancement revoke @s only trinkery:trinket/speed/3

execute unless predicate {"condition": "minecraft:random_chance","chance": 0.35} run return fail

effect give @s minecraft:swiftness 6 1 false