execute as @n[type=#minecraft:arrows,tag=!trinkery.arrow.piercing,nbt=!{inGround:1b}] run function trinkery:trinket/piercing/piercing {"piercing":3}
