execute if predicate {"condition": "minecraft:random_chance","chance": 0.1} run give @s minecraft:experience_bottle 1
