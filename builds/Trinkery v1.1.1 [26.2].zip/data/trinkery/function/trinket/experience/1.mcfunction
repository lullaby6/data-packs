execute if predicate {"condition": "minecraft:random_chance","chance": 0.01} run give @s minecraft:experience_bottle 1
