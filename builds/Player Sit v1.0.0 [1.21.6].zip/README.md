# Player Sit

[![Discord](https://img.shields.io/discord/1327308441324097681?label=discord&color=blue&logo=discord)](https://discord.gg/5UdcDa5xNC)
[![Modrinth](https://img.shields.io/modrinth/dt/player-sit?label=modrinth&logo=modrinth)](https://modrinth.com/datapack/player-sit)
[![License](https://img.shields.io/github/license/lullaby6/data-packs)](https://github.com/lullaby6/data-packs/blob/main/LICENSE)

## 📖 Description

Simple Player Sit! use the Quick Actions key (`G`) to see the gui to sit or do `/trigger sit`!

## ⌨️ Commands

Sit:

```mcfunction
/trigger sit
```

## 🪪 License

[AGPL-3.0-or-later](https://github.com/lullaby6/data-packs/blob/main/LICENSE)