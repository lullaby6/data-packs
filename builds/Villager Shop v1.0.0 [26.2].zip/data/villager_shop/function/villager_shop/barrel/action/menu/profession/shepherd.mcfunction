data modify entity @s data."villager_shop:data"."profession" set value "shepherd"

data modify entity @n[tag=villager_shop.villager,distance=..1] VillagerData.profession set value "minecraft:shepherd"

