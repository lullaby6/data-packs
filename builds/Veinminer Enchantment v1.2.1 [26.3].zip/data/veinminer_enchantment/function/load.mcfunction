scoreboard objectives add veinminer_enchantment.player.use.wooden_pickaxe minecraft.used:minecraft.wooden_pickaxe
scoreboard objectives add veinminer_enchantment.player.use.copper_pickaxe minecraft.used:minecraft.copper_pickaxe
scoreboard objectives add veinminer_enchantment.player.use.stone_pickaxe minecraft.used:minecraft.stone_pickaxe
scoreboard objectives add veinminer_enchantment.player.use.iron_pickaxe minecraft.used:minecraft.iron_pickaxe
scoreboard objectives add veinminer_enchantment.player.use.golden_pickaxe minecraft.used:minecraft.golden_pickaxe
scoreboard objectives add veinminer_enchantment.player.use.diamond_pickaxe minecraft.used:minecraft.diamond_pickaxe
scoreboard objectives add veinminer_enchantment.player.use.netherite_pickaxe minecraft.used:minecraft.netherite_pickaxe