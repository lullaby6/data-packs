forceload remove ~ ~

kill @s
