# Vision Enchantment

[![Discord](https://img.shields.io/discord/1327308441324097681?label=discord&color=blue&logo=discord)](https://discord.gg/5UdcDa5xNC)
[![Modrinth](https://img.shields.io/modrinth/dt/vision-enchantment-data-pack?label=modrinth&logo=modrinth)](https://modrinth.com/datapack/vision-enchantment)
[![License](https://img.shields.io/github/license/lullaby6/enchantments-data-pack)](https://github.com/lullaby6/enchantments-data-pack/blob/main/LICENSE)

Vision enchantment for helmets, gain night vision with a enchantment!

The enchantment can be obtained from the enchantment table, loot chests or trading with villagers.

## ⌨️ Commands

Give:

```mcfunction
/loot give @s loot vision_enchantment:vision
```

Enchant:

```mcfunction
/enchant @s vision_enchantment:vision
```

## 🪪 License

[AGPL-3.0-or-later](https://github.com/lullaby6/enchantments-data-pack/blob/main/LICENSE)