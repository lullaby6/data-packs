# Swiftness Enchantment

[![Discord](https://img.shields.io/discord/1327308441324097681?label=discord&color=blue&logo=discord)](https://discord.gg/5UdcDa5xNC)
[![Modrinth](https://img.shields.io/modrinth/dt/swiftness-enchantment-data-pack?label=modrinth&logo=modrinth)](https://modrinth.com/datapack/swiftness-enchantment)
[![License](https://img.shields.io/github/license/lullaby6/enchantments-data-pack)](https://github.com/lullaby6/enchantments-data-pack/blob/main/LICENSE)

`Swiftness` is a new enchantment for boots with four levels that increases your movement speed.

The enchantment can be obtained from the enchantment table, loot chests or trading with villagers.

## ⌨️ Commands

Give:

```mcfunction
/loot give @s loot swiftness_enchantment:<level>
```

Enchant:

```mcfunction
/enchant @s swiftness_enchantment:swiftness <level>
```

## 🪪 License

[AGPL-3.0-or-later](https://github.com/lullaby6/enchantments-data-pack/blob/main/LICENSE)