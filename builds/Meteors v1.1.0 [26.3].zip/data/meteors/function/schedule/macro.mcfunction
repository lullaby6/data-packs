$schedule function meteors:schedule/meteor $(schedule)s replace
