scoreboard objectives add magnetic_enchantment.delay dummy
scoreboard objectives add magnetic_enchantment.x dummy
scoreboard objectives add magnetic_enchantment.y dummy
scoreboard objectives add magnetic_enchantment.z dummy

scoreboard objectives add magnetic_enchantment.player.timer.killed_entity dummy

scoreboard objectives add magnetic_enchantment.player.use.wooden_pickaxe minecraft.used:minecraft.wooden_pickaxe
scoreboard objectives add magnetic_enchantment.player.use.stone_pickaxe minecraft.used:minecraft.stone_pickaxe
scoreboard objectives add magnetic_enchantment.player.use.iron_pickaxe minecraft.used:minecraft.iron_pickaxe
scoreboard objectives add magnetic_enchantment.player.use.golden_pickaxe minecraft.used:minecraft.golden_pickaxe
scoreboard objectives add magnetic_enchantment.player.use.diamond_pickaxe minecraft.used:minecraft.diamond_pickaxe
scoreboard objectives add magnetic_enchantment.player.use.netherite_pickaxe minecraft.used:minecraft.netherite_pickaxe

scoreboard objectives add magnetic_enchantment.player.use.wooden_axe minecraft.used:minecraft.wooden_axe
scoreboard objectives add magnetic_enchantment.player.use.stone_axe minecraft.used:minecraft.stone_axe
scoreboard objectives add magnetic_enchantment.player.use.iron_axe minecraft.used:minecraft.iron_axe
scoreboard objectives add magnetic_enchantment.player.use.golden_axe minecraft.used:minecraft.golden_axe
scoreboard objectives add magnetic_enchantment.player.use.diamond_axe minecraft.used:minecraft.diamond_axe
scoreboard objectives add magnetic_enchantment.player.use.netherite_axe minecraft.used:minecraft.netherite_axe

scoreboard objectives add magnetic_enchantment.player.use.wooden_shovel minecraft.used:minecraft.wooden_shovel
scoreboard objectives add magnetic_enchantment.player.use.stone_shovel minecraft.used:minecraft.stone_shovel
scoreboard objectives add magnetic_enchantment.player.use.iron_shovel minecraft.used:minecraft.iron_shovel
scoreboard objectives add magnetic_enchantment.player.use.golden_shovel minecraft.used:minecraft.golden_shovel
scoreboard objectives add magnetic_enchantment.player.use.diamond_shovel minecraft.used:minecraft.diamond_shovel
scoreboard objectives add magnetic_enchantment.player.use.netherite_shovel minecraft.used:minecraft.netherite_shovel

scoreboard objectives add magnetic_enchantment.player.use.wooden_hoe minecraft.used:minecraft.wooden_hoe
scoreboard objectives add magnetic_enchantment.player.use.stone_hoe minecraft.used:minecraft.stone_hoe
scoreboard objectives add magnetic_enchantment.player.use.iron_hoe minecraft.used:minecraft.iron_hoe
scoreboard objectives add magnetic_enchantment.player.use.golden_hoe minecraft.used:minecraft.golden_hoe
scoreboard objectives add magnetic_enchantment.player.use.diamond_hoe minecraft.used:minecraft.diamond_hoe
scoreboard objectives add magnetic_enchantment.player.use.netherite_hoe minecraft.used:minecraft.netherite_hoe

scoreboard objectives add magnetic_enchantment.player.use.shears minecraft.used:minecraft.shears