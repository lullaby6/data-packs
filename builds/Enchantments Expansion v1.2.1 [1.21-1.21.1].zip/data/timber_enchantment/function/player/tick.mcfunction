execute unless predicate timber_enchantment:player/is_sneaking if predicate timber_enchantment:enchantment/timber run function timber_enchantment:timber/holding

function timber_enchantment:player/reset