scoreboard players remove job.digger.amount economy.config 5

execute if score job.digger.amount economy.config matches ..-1 run scoreboard players set job.digger.amount economy.config 0

function economy:config/jobs
