# Undying Enchantment

[![Discord](https://img.shields.io/discord/1327308441324097681?label=discord&color=blue&logo=discord)](https://discord.gg/5UdcDa5xNC)
[![Modrinth](https://img.shields.io/modrinth/dt/undying-enchantment-data-pack?label=modrinth&logo=modrinth)](https://modrinth.com/datapack/;ly-undying-enchantment)
[![License](https://img.shields.io/github/license/lullaby6/enchantments-data-pack)](https://github.com/lullaby6/enchantments-data-pack/blob/main/LICENSE)

Undying Enchantment for shields! undecided whether to use shields or totems of undying? then use the shield with the Undying Enchantment!

The enchantment can be obtained from the enchantment table, loot chests or trading with villagers.

## ⌨️ Commands

Give:

```mcfunction
/loot give @s loot undying_enchantment:undying
```

Enchant:

```mcfunction
/enchant @s undying_enchantment:undying
```

## 🪪 License

[AGPL-3.0-or-later](https://github.com/lullaby6/enchantments-data-pack/blob/main/LICENSE)